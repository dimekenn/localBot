create unique index GROUPS_ID_UINDEX
    on GROUPS (ID);

