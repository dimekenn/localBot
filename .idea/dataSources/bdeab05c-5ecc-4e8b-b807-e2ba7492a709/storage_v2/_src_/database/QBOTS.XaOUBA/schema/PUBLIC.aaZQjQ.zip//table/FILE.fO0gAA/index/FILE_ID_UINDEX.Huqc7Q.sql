create unique index FILE_ID_UINDEX
    on FILE (ID);

