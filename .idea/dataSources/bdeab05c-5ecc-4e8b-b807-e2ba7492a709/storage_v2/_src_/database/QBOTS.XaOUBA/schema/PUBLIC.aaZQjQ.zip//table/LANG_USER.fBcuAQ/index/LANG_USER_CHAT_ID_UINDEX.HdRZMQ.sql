create unique index LANG_USER_CHAT_ID_UINDEX
    on LANG_USER (CHAT_ID);

