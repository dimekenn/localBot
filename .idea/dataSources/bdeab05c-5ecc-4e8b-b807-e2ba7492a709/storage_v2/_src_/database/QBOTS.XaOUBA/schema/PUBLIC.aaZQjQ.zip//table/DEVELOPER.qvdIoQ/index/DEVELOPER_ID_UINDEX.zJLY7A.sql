create unique index DEVELOPER_ID_UINDEX
    on DEVELOPER (ID);

