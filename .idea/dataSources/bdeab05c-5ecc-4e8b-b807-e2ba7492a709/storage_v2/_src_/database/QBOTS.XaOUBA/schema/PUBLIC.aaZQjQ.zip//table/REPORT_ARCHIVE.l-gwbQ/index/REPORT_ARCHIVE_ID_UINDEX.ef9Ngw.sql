create unique index REPORT_ARCHIVE_ID_UINDEX
    on REPORT_ARCHIVE (ID);

