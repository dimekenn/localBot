create unique index REPORT_ID_UINDEX
    on REPORT (ID);

