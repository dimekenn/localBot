create unique index REQUEST_ID_UINDEX
    on REQUEST (ID);

